This Font I created for the world leader in salmon slicing machines: Maass Salmon Slicers. It was inspired by their logo.

If you want to chop tons of salmon, visit http://www.maass-slicers.de/

If you like to use this font, please drop me a note at: wiegel@aepnet.de

This Font is freeware. However it is Not Public Domain.
You are allowed to share this font (including this readme-file) without asking for any fee 
and to use it however and howoften you want (but please not for something like slicing salmons or other fish :-) 
if you are not Mass.  ).
If you want to add this to your Font-Download-Page, please drop me a note.
And please ask me, if you want to put it on a commercial Font-CD ore some other commercial software product.
----
Update Notice: Jan.2007:  I have removed the Maass-Logos, cause the company asked me to do this. And as I had to edit the font, I have added a lot of more glyphs: 
I have addes lowercase letters, the complete set of european "Latin Extended A" glyphs fpr all the west and east european languages,
greek glyphs as well as kyrillic letters, including special letters for other countries than russia using kyrillic writing. 

(c) P. Wiegel CAT-Design Wolgast
